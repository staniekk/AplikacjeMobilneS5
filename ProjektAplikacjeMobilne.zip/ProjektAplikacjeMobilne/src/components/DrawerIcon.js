// import {StyleSheet, Image} from "react-native";

// export const BottomTabIcon = ({ routeName, focused }) => {
        
//             return <Image
//                 style={styles.imgActive}
//                 source={require('./../img/drawerNav/HamburgerIcon.png')}
//             />
//     }



// const styles = StyleSheet.create({
//     img:{
//         width: 28,
//         height: 28
//     },
//     imgActive: {
//         width: 40,
//         height: 40
//     }
// })
