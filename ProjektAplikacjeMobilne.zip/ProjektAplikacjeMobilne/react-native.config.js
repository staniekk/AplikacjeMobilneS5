module.exports = {
    assets:  ['./assets/fonts/'], // Zastąp ścieżką do Twojego folderu z czcionkami
  };
  